[] organize your project directory
[] use table to structure the top-level UI
[] use jquery for some prefab widgets